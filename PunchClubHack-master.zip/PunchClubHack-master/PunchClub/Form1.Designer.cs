﻿namespace PunchClub
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
      this.save_1 = new System.Windows.Forms.RadioButton();
      this.save_2 = new System.Windows.Forms.RadioButton();
      this.save_3 = new System.Windows.Forms.RadioButton();
      this.label1 = new System.Windows.Forms.Label();
      this.money = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.sp = new System.Windows.Forms.TextBox();
      this.strength = new System.Windows.Forms.TextBox();
      this.agility = new System.Windows.Forms.TextBox();
      this.stamina = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.hack = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // save_1
      // 
      this.save_1.AutoSize = true;
      this.save_1.Location = new System.Drawing.Point(12, 12);
      this.save_1.Name = "save_1";
      this.save_1.Size = new System.Drawing.Size(60, 17);
      this.save_1.TabIndex = 0;
      this.save_1.TabStop = true;
      this.save_1.Text = "save_1";
      this.save_1.UseVisualStyleBackColor = true;
      // 
      // save_2
      // 
      this.save_2.AutoSize = true;
      this.save_2.Location = new System.Drawing.Point(78, 12);
      this.save_2.Name = "save_2";
      this.save_2.Size = new System.Drawing.Size(60, 17);
      this.save_2.TabIndex = 1;
      this.save_2.TabStop = true;
      this.save_2.Text = "save_2";
      this.save_2.UseVisualStyleBackColor = true;
      // 
      // save_3
      // 
      this.save_3.AutoSize = true;
      this.save_3.Location = new System.Drawing.Point(144, 12);
      this.save_3.Name = "save_3";
      this.save_3.Size = new System.Drawing.Size(60, 17);
      this.save_3.TabIndex = 2;
      this.save_3.TabStop = true;
      this.save_3.Text = "save_3";
      this.save_3.UseVisualStyleBackColor = true;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(9, 38);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(39, 13);
      this.label1.TabIndex = 3;
      this.label1.Text = "Money";
      // 
      // money
      // 
      this.money.Location = new System.Drawing.Point(73, 35);
      this.money.Name = "money";
      this.money.Size = new System.Drawing.Size(199, 20);
      this.money.TabIndex = 4;
      this.money.Text = "9999";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(9, 65);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(55, 13);
      this.label2.TabIndex = 5;
      this.label2.Text = "SkillPoints";
      // 
      // sp
      // 
      this.sp.Location = new System.Drawing.Point(73, 62);
      this.sp.Name = "sp";
      this.sp.Size = new System.Drawing.Size(199, 20);
      this.sp.TabIndex = 6;
      this.sp.Text = "2331";
      // 
      // strength
      // 
      this.strength.Location = new System.Drawing.Point(73, 88);
      this.strength.Name = "strength";
      this.strength.Size = new System.Drawing.Size(199, 20);
      this.strength.TabIndex = 7;
      this.strength.Text = "24000";
      // 
      // agility
      // 
      this.agility.Location = new System.Drawing.Point(73, 114);
      this.agility.Name = "agility";
      this.agility.Size = new System.Drawing.Size(199, 20);
      this.agility.TabIndex = 8;
      this.agility.Text = "24000";
      // 
      // stamina
      // 
      this.stamina.Location = new System.Drawing.Point(73, 140);
      this.stamina.Name = "stamina";
      this.stamina.Size = new System.Drawing.Size(199, 20);
      this.stamina.TabIndex = 9;
      this.stamina.Text = "24000";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(9, 91);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(47, 13);
      this.label3.TabIndex = 10;
      this.label3.Text = "Strength";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(9, 117);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(34, 13);
      this.label4.TabIndex = 11;
      this.label4.Text = "Agility";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(9, 143);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(45, 13);
      this.label5.TabIndex = 12;
      this.label5.Text = "Stamina";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(9, 167);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(276, 78);
      this.label6.TabIndex = 13;
      this.label6.Text = resources.GetString("label6.Text");
      // 
      // hack
      // 
      this.hack.Location = new System.Drawing.Point(12, 252);
      this.hack.Name = "hack";
      this.hack.Size = new System.Drawing.Size(260, 23);
      this.hack.TabIndex = 14;
      this.hack.Text = "Hack Savegame";
      this.hack.UseVisualStyleBackColor = true;
      this.hack.Click += new System.EventHandler(this.hack_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(284, 287);
      this.Controls.Add(this.hack);
      this.Controls.Add(this.label6);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.stamina);
      this.Controls.Add(this.agility);
      this.Controls.Add(this.strength);
      this.Controls.Add(this.sp);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.money);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.save_3);
      this.Controls.Add(this.save_2);
      this.Controls.Add(this.save_1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.Name = "Form1";
      this.Text = "PunchClub Save Editor";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.RadioButton save_1;
    private System.Windows.Forms.RadioButton save_2;
    private System.Windows.Forms.RadioButton save_3;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox money;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox sp;
    private System.Windows.Forms.TextBox strength;
    private System.Windows.Forms.TextBox agility;
    private System.Windows.Forms.TextBox stamina;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Button hack;
  }
}

